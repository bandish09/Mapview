//
//  ViewController.swift
//  MapView
//
//  Created by Bandish on 08/10/20.
//  Copyright © 2020 Bandish. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

struct Store {
  var name: String
  var lattitude: CLLocationDegrees
  var longtitude: CLLocationDegrees
}



class ViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    let radius: CLLocationDistance = 5000
    let startingLocation = CLLocation(latitude: 23.2156, longitude: 72.6369) //Gandhinagar

    var locRoute : MKRoute?
    var directionsRequest = MKDirections.Request()
    var arrayarrayPlacemarks = [MKMapItem]()
    var selectedPin:MKPlacemark? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.mapView.delegate = self
        setStartingPosition()
        let stores = self.getStoreLocation()
        self.setAnnotation(stores: stores)
        //self.createPolyline(stors: stores)
        self.createPolyline1(stores: stores)

    }
    
    override func viewDidAppear(_ animated: Bool) {
        isLocationServiceEnabled()
    }

    
    func setStartingPosition(){
        let region = MKCoordinateRegion(center: startingLocation.coordinate, latitudinalMeters:radius , longitudinalMeters: radius)
        mapView.setRegion(region, animated: true)
    }

    
    func createPolyline1(stores: [Store]) {
        for store in stores{
            let temp = MKPlacemark(coordinate: CLLocationCoordinate2DMake(store.lattitude, store.longtitude))
            self.arrayarrayPlacemarks.append(MKMapItem(placemark: temp))
        }
        directionsRequest.transportType = MKDirectionsTransportType.automobile
        //Draw polyline by using MKRoute so it follows the street roads...
        for (k, item) in arrayarrayPlacemarks.enumerated() {
            if k < (arrayarrayPlacemarks.count - 1) {
                directionsRequest.source = item
                directionsRequest.destination = arrayarrayPlacemarks[k+1]
                let directions = MKDirections(request: directionsRequest)
                
                directions.calculate { (response:MKDirections.Response!, error: Error!) -> Void in
                    if error == nil {
                        self.locRoute = response.routes[0]
                        let geodesic:MKPolyline = self.locRoute!.polyline
                        self.mapView.addOverlay(geodesic)
                    }
                }
        }}

    }
    
    func createPolyline(stors: [Store]) {
        
        var points = [CLLocationCoordinate2D]()
        for store in stors{
            points.append(CLLocationCoordinate2DMake(store.lattitude, store.longtitude))
        }
        
        let geodesic = MKGeodesicPolyline(coordinates: points, count: 2)
        self.mapView.addOverlay(geodesic)
        
        UIView.animate(withDuration: 1.5, animations: { () -> Void in
            let region = MKCoordinateRegion(center: points[1], latitudinalMeters:self.radius , longitudinalMeters: self.radius)
            self.mapView.setRegion(region, animated: true)
        })
    }
    
    func getStoreLocation() -> [Store]{
            return [
                Store(name: "Gandhinagar", lattitude: 23.2156, longtitude: 72.6369),
                Store(name: "Sarghasan", lattitude: 23.1929, longtitude: 72.6156),
            ]
        }
        
        func setAnnotation(stores:[Store]){
            for store in stores {
                let annotation = MKPointAnnotation()
                annotation.title = store.name
                annotation.coordinate = CLLocationCoordinate2D(latitude:store.lattitude,
                                                             longitude: store.longtitude)
                mapView.addAnnotation(annotation)
            }
        }
    
    
    
    func isLocationServiceEnabled(){
        if CLLocationManager.locationServicesEnabled(){
            checkAuthorizationStatus()
        }
        else{
            displayAlert(isServiceEnabled: true)
        }
    }
    
    func configureLocationManger(){
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.mapView.showsUserLocation = true
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
    }
    
    func checkAuthorizationStatus(){
            
            let status = CLLocationManager.authorizationStatus()
            if status == .authorizedAlways || status == .authorizedWhenInUse {
                self.configureLocationManger()
            }
            else if status == .restricted || status == .denied {
                displayAlert(isServiceEnabled: false)
            }
            else if status == .notDetermined {
                
                self.configureLocationManger()
            }
    }
    
    func displayAlert(isServiceEnabled:Bool){
      
            let serviceEnableMessage = "Location services must to be enabled to use this awesome app feature. You can enable location services in your settings."
            let authorizationStatusMessage = "This awesome app needs authorization to do some cool stuff with the map"
            
            let message = isServiceEnabled ? serviceEnableMessage : authorizationStatusMessage
            
            let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
            
            //create ok button
            let acceptAction = UIAlertAction(title: "OK", style: .default)
            
            //add ok button to alert
            alert.addAction(acceptAction)
            self.present(alert, animated: true, completion: nil)
    }



}

extension ViewController: MKMapViewDelegate{
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay.isKind(of: MKPolyline.self){
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.fillColor = UIColor.blue
            polylineRenderer.strokeColor = UIColor.blue
            polylineRenderer.lineWidth = 2
            return polylineRenderer
        }
        return MKOverlayRenderer(overlay: overlay)
        
    }
}


extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("update locaton calling...")
    }
}
